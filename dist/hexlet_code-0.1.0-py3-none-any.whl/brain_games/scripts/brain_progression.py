#!/usr/bin/env python
from brain_games.games.progression_games import caclulate
from brain_games.games.logic_games import tune


def main():
    tune(caclulate)


if __name__ == '__main__':
    main()

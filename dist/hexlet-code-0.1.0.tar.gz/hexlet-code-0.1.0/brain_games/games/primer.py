def corr_str():
        question = ''
        for number in list:
            question = question + str(number) + " "
        return question
    print
from random import randint


def random_number():
    random_number = randint(1, 100)
    return random_number

from prompt import string
from even_games2 import manual, caclulation
name = string('May I have your name? ')
question = caclulation()[0]
answer = caclulation()[1]


print(question)
print(answer)